        $('.AnimaTion1').mousemove(
            function () {
                $('.AnimaTion1').attr('src', './卡-img/桌機index_img/icon1-1.png')
            }
        )
        $('.AnimaTion1').mouseout(
            function () {
                $('.AnimaTion1').attr('src', './卡-img/桌機index_img/icon1.png')
            }
        )
        // ----------------------
        $('.AnimaTion2').mousemove(
            function () {
                $('.AnimaTion2').attr('src', './卡-img/桌機index_img/icon2-1.png')
            }
        )
        $('.AnimaTion2').mouseout(
            function () {
                $('.AnimaTion2').attr('src', './卡-img/桌機index_img/icon2.png')
            }
        )
        // ----------------------
        $('.AnimaTion3').mousemove(
            function () {
                $('.AnimaTion3').attr('src', './卡-img/桌機index_img/icon3-1.png')
            }
        )
        $('.AnimaTion3').mouseout(
            function () {
                $('.AnimaTion3').attr('src', './卡-img/桌機index_img/icon3.png')
            }
        )
        // ----------------------
        $('.AnimaTion4').mousemove(
            function () {
                $('.AnimaTion4').attr('src', './卡-img/桌機index_img/icon4-1.png')
            }
        )
        $('.AnimaTion4').mouseout(
            function () {
                $('.AnimaTion4').attr('src', './卡-img/桌機index_img/icon4.png')
            }
        )
        // ----------------------
        $('.AnimaTion5').mousemove(
            function () {
                $('.AnimaTion5').attr('src', './卡-img/桌機index_img/icon5-1.png')
            }
        )
        $('.AnimaTion5').mouseout(
            function () {
                $('.AnimaTion5').attr('src', './卡-img/桌機index_img/icon5.png')
            }
        )
        // ----------------------
        $('.AnimaTion6').mousemove(
            function () {
                $('.AnimaTion6').attr('src', './卡-img/桌機index_img/icon6-1.png')
            }
        )
        $('.AnimaTion6').mouseout(
            function () {
                $('.AnimaTion6').attr('src', './卡-img/桌機index_img/icon6.png')
            }
        )
        // ----------------------
        $('.AnimaTion7').mousemove(
            function () {
                $('.AnimaTion7').attr('src', './卡-img/桌機index_img/icon7-1.png')
            }
        )
        $('.AnimaTion7').mouseout(
            function () {
                $('.AnimaTion7').attr('src', './卡-img/桌機index_img/icon7.png')
            }
        )
        // ----------------------
        $('.AnimaTion8').mousemove(
            function () {
                $('.AnimaTion8').attr('src', './卡-img/桌機index_img/icon8-1.png')
            }
        )
        $('.AnimaTion8').mouseout(
            function () {
                $('.AnimaTion8').attr('src', './卡-img/桌機index_img/icon8.png')
            }
        )